package qap1_java;

public class TestAccount {
    public static void main(String[] args) {
        Account Acc1 = new Account("1", "Bob", 5000);
        Account Acc2 = new Account("2", "Jane", 4000);
        
        System.out.println(Acc1.getBal());
        System.out.println(Acc2.getBal());
        Acc1.transferTo(Acc2, 1000);
        System.out.println();
        System.out.println(Acc1.getBal());
        System.out.println(Acc2.getBal());
        
    }
    
}
