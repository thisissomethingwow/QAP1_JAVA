package qap1_java;

public class TestDate {
    public static void main(String[] args) {
        Date date = new Date(14, 5, 2024);

        System.out.println(date.toString());
    }

    
}